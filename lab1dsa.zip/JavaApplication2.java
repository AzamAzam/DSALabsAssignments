/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication2;

import java.util.*;

/**
 *
 * @author bcsf15m017
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
//        System.out.println("Hello World");
           Scanner in=new Scanner(System.in);
        int n;
        System.out.println("Enter a number : ");
        n=in.nextInt(); //input 
  int count =0;
  int i;
  for (int j=2;count<n ;j++)
  {
      for ( i=2;i<j;i++)
      { 
          if (j%i==0)
              i=j+1;
      }
      if (i==j){
          System.out.print(i);  
           System.out.print(" ");  
           count ++;
      }
      
  }
        
       System.out.println(" ");    
}
    }
    

