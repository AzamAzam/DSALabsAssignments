/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package student;

import java.util.*;

/**
 *
 * @author bcsf15m017
 */
public class Student {

   String  studentId;
    String  name;
    double age ;
    //public:
    public Student(){
       studentId=null;
       name=null;
       age=0;
        
    }
    public void setValues()
    {
        Scanner in=new Scanner(System.in);

            System.out.println("Enter Name  : ");
            name=in.next(); //input 
            System.out.println("Enter Student ID   : ");
            studentId=in.next(); //input 
            System.out.println("Enter age  : ");
            age=in.nextDouble(); //input 
    }
    public double getAge(){
        return age;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
     System.out.print("Enter Number of Students ");
     int n;
      Scanner in=new Scanner(System.in);
            n=in.nextInt(); //input 
         Student std[] =new Student[n];
        for(int i=0;i<n;i++){
            std[i]=new Student();
        }
        
       // System.out.println(" En");
         for(int i=0;i<n;i++){
            System.out.print("Data of Student");
            System.out.print(i+1);
            System.out.println("  : ");
            std[i].setValues();
    }
         System.out.print("Average Age = ");
         double totalAge=0;
         for(int i=0;i<n;i++)
         { 
         totalAge=totalAge+std[i].getAge();
             
         }
         System.out.println(totalAge/10);
    }
    
}
