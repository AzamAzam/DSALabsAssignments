/*MUAMMAD AZAM
BCSF15M017*/
#include"LOGs.h"
int main ( ) {
	system ( "mode con:cols=150 lines=9999" );

	logs f;
	f.readFile ( );
	f.display ( );
}