/*MUHAMMAD AZAM
BCSF15M017*/

#include"DoubleLinkList.h"
int main ( )  {
	DoubleLinkList l;
	cout << "Enter size  of link list ";
	int size;
	cin >> size;
	l.createLinkList (size );
	cout << "List created "<<endl;
	l.display ( );

	cout << "Enter data  you want  to enqueue ";
	int d;
	cin >> d;
	l.enqueue ( d);
	cout << "After enqueue " << endl;
	l.display ( );

	cout << "Enter Node Number you want  to delete : ";
	int n;
	cin >> n;
	l.deleteIthNode (n );
	cout << "After deleting Required NOde : ";
	l.display ( );
}